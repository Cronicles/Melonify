import os
import shutil

def replace_textures(src_folder, dest_folder, melon_texture_path):
    # Erstelle das Zielverzeichnis, falls es nicht existiert
    if not os.path.exists(dest_folder):
        os.makedirs(dest_folder)
    
    # Durchlaufen des Quellordners
    for root, dirs, files in os.walk(src_folder):
        for file in files:
            # Überprüfen, ob die Datei eine Bilddatei ist
            if file.endswith('.png'):
                # Erstelle den entsprechenden Zielpfad
                relative_path = os.path.relpath(root, src_folder)
                dest_dir = os.path.join(dest_folder, relative_path)
                dest_file_path = os.path.join(dest_dir, file)
                
                # Erstelle das Zielverzeichnis, falls es nicht existiert
                if not os.path.exists(dest_dir):
                    os.makedirs(dest_dir)
                
                # Kopiere die Melonen-Textur zur Zieldatei
                shutil.copy(melon_texture_path, dest_file_path)
                print(f'Ersetze {file} mit der Melonen-Textur')
                
    print('Alle Texturen wurden ersetzt!')

# Pfade anpassen
source_folder = r'C:\Users\kalle\OneDrive\Desktop\Melonified\default_textures\assets\minecraft\textures'
destination_folder = r'C:\Users\kalle\OneDrive\Desktop\Melonified\assets\minecraft\textures'
melon_texture = r'C:\Users\kalle\OneDrive\Desktop\Melonified\pack.png'

# Skript ausführen
replace_textures(source_folder, destination_folder, melon_texture)
